This project now includes a 'prices' table in SQLite for future automation.

- Table: prices(symbol, date, open, high, low, close, volume, source)
- Unique key: (symbol, date)

Not used by the UI yet.
Later we can add an import endpoint (CSV) and an auto-scoring job that checks
whether each recommendation hit its target within the defined date range.
